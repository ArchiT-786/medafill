// File: components/layout/patients-sidebar.tsx

"use client";

import { Fragment, useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, PanelLeftClose, PanelRightClose } from "lucide-react";

import { SidebarNavItem } from "@/types";
import { siteConfig } from "@/config/site";
import { cn } from "@/lib/utils";
import { useMediaQuery } from "@/hooks/use-media-query";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Icons } from "@/components/shared/icons";

interface DashboardSidebarProps {
  links: SidebarNavItem[];
}

export function DashboardSidebar({
  links,
}: DashboardSidebarProps) {
  const path = usePathname();

  const { isTablet } = useMediaQuery();

  const [isSidebarExpanded, setIsSidebarExpanded] =
    useState(!isTablet);

  const toggleSidebar = () => {
    setIsSidebarExpanded(!isSidebarExpanded);
  };

  useEffect(() => {
    setIsSidebarExpanded(!isTablet);
  }, [isTablet]);

  return (
    <TooltipProvider delayDuration={0}>
      <div className="sticky top-0 h-full">
        <ScrollArea className="h-full overflow-y-auto border-r">
          <aside
            className={cn(
              isSidebarExpanded
                ? "w-[220px] xl:w-[260px]"
                : "w-[68px]",
              "hidden h-screen md:block",
            )}
          >
            <div className="flex h-full max-h-screen flex-1 flex-col gap-2">

              {/* Sidebar Header / Logo */}
              <div
                className={cn(
                  "flex h-14 items-center border-b px-4 lg:h-[60px]",
                  !isSidebarExpanded &&
                    "justify-center px-2",
                )}
              >
                {isSidebarExpanded ? (
                  <Link
                    href="/patients"
                    className="flex items-center gap-2"
                  >
                    <div className="flex size-9 shrink-0 items-center justify-center overflow-hidden rounded-lg">
                      <img
                        src="/logo.png"
                        alt={siteConfig.name}
                        className="size-full object-contain"
                      />
                    </div>

                    <span className="truncate text-lg font-bold">
                      {siteConfig.name}
                    </span>
                  </Link>
                ) : (
                  <Link
                    href="/patients"
                    className="flex items-center justify-center"
                  >
                    <div className="flex size-9 items-center justify-center overflow-hidden rounded-lg">
                      <img
                        src="/logo.png"
                        alt={siteConfig.name}
                        className="size-full object-contain"
                      />
                    </div>
                  </Link>
                )}

                <Button
                  variant="ghost"
                  size="icon"
                  className={cn(
                    "size-9 lg:size-8",
                    isSidebarExpanded
                      ? "ml-auto"
                      : "absolute right-2 top-3",
                  )}
                  onClick={toggleSidebar}
                >
                  {isSidebarExpanded ? (
                    <PanelLeftClose
                      size={18}
                      className="stroke-muted-foreground"
                    />
                  ) : (
                    <PanelRightClose
                      size={18}
                      className="stroke-muted-foreground"
                    />
                  )}

                  <span className="sr-only">
                    Toggle Sidebar
                  </span>
                </Button>
              </div>

              {/* Navigation */}
              <nav className="flex flex-1 flex-col gap-8 px-4 pt-4">
                {links.map((section) => (
                  <section
                    key={section.title}
                    className="flex flex-col gap-0.5"
                  >
                    {isSidebarExpanded ? (
                      <p className="text-xs text-muted-foreground">
                        {section.title}
                      </p>
                    ) : (
                      <div className="h-4" />
                    )}

                    {section.items.map((item) => {
                      const Icon =
                        Icons[item.icon || "arrowRight"];

                      return (
                        item.href && (
                          <Fragment
                            key={`link-fragment-${item.title}`}
                          >
                            {isSidebarExpanded ? (
                              <Link
                                href={
                                  item.disabled
                                    ? "#"
                                    : item.href
                                }
                                className={cn(
                                  "flex items-center gap-3 rounded-md p-2 text-sm font-medium hover:bg-muted",
                                  path === item.href
                                    ? "bg-muted"
                                    : "text-muted-foreground hover:text-accent-foreground",
                                  item.disabled &&
                                    "cursor-not-allowed opacity-80 hover:bg-transparent hover:text-muted-foreground",
                                )}
                              >
                                <Icon className="size-5" />

                                {item.title}

                                {item.badge && (
                                  <Badge className="ml-auto flex size-5 shrink-0 items-center justify-center rounded-full">
                                    {item.badge}
                                  </Badge>
                                )}
                              </Link>
                            ) : (
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Link
                                    href={
                                      item.disabled
                                        ? "#"
                                        : item.href
                                    }
                                    className={cn(
                                      "flex items-center gap-3 rounded-md py-2 text-sm font-medium hover:bg-muted",
                                      path === item.href
                                        ? "bg-muted"
                                        : "text-muted-foreground hover:text-accent-foreground",
                                      item.disabled &&
                                        "cursor-not-allowed opacity-80 hover:bg-transparent hover:text-muted-foreground",
                                    )}
                                  >
                                    <span className="flex size-full items-center justify-center">
                                      <Icon className="size-5" />
                                    </span>
                                  </Link>
                                </TooltipTrigger>

                                <TooltipContent side="right">
                                  {item.title}
                                </TooltipContent>
                              </Tooltip>
                            )}
                          </Fragment>
                        )
                      );
                    })}
                  </section>
                ))}
              </nav>
            </div>
          </aside>
        </ScrollArea>
      </div>
    </TooltipProvider>
  );
}

export function MobileSheetSidebar({
  links,
}: DashboardSidebarProps) {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  const { isSm, isMobile } = useMediaQuery();

  if (isSm || isMobile) {
    return (
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button
            variant="outline"
            size="icon"
            className="size-9 shrink-0 md:hidden"
          >
            <Menu className="size-5" />
            <span className="sr-only">
              Toggle navigation menu
            </span>
          </Button>
        </SheetTrigger>

        <SheetContent
          side="left"
          className="flex flex-col p-0"
        >
          <ScrollArea className="h-full overflow-y-auto">
            <div className="flex h-screen flex-col">
              <nav className="flex flex-1 flex-col gap-y-8 p-6 text-lg font-medium">

                {/* Mobile Logo */}
                <Link
                  href="/patients"
                  className="flex items-center gap-2"
                >
                  <div className="flex size-9 shrink-0 items-center justify-center overflow-hidden rounded-lg">
                    <img
                      src="/logo.png"
                      alt={siteConfig.name}
                      className="size-full object-contain"
                    />
                  </div>

                  <span className="font-urban text-xl font-bold">
                    {siteConfig.name}
                  </span>
                </Link>

                {links.map((section) => (
                  <section
                    key={section.title}
                    className="flex flex-col gap-0.5"
                  >
                    <p className="text-xs text-muted-foreground">
                      {section.title}
                    </p>

                    {section.items.map((item) => {
                      const Icon =
                        Icons[item.icon || "arrowRight"];

                      return (
                        item.href && (
                          <Fragment
                            key={`link-fragment-${item.title}`}
                          >
                            <Link
                              onClick={() => {
                                if (!item.disabled) {
                                  setOpen(false);
                                }
                              }}
                              href={
                                item.disabled
                                  ? "#"
                                  : item.href
                              }
                              className={cn(
                                "flex items-center gap-3 rounded-md p-2 text-sm font-medium hover:bg-muted",
                                path === item.href
                                  ? "bg-muted"
                                  : "text-muted-foreground hover:text-accent-foreground",
                                item.disabled &&
                                  "cursor-not-allowed opacity-80 hover:bg-transparent hover:text-muted-foreground",
                              )}
                            >
                              <Icon className="size-5" />

                              {item.title}

                              {item.badge && (
                                <Badge className="ml-auto flex size-5 shrink-0 items-center justify-center rounded-full">
                                  {item.badge}
                                </Badge>
                              )}
                            </Link>
                          </Fragment>
                        )
                      );
                    })}
                  </section>
                ))}
              </nav>
            </div>
          </ScrollArea>
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <div className="flex size-9 animate-pulse rounded-lg bg-muted md:hidden" />
  );
}